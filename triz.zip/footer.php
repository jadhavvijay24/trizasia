<footer>
            
            <div class="footer-area-bottom">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="copyright">
							
                                <p>
                                    Copyright © 2017
                                    <a href="#">ConsultExperts</a> All Rights Reserved
                                </p>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="copyright">
                                <ul>
                                    <li><a href="#">About</a></li>
                                    <li><a href="#">Terms</a></li>
                                    <li><a href="#">Private</a></li>
                                    <li><a href="#">Policy</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>